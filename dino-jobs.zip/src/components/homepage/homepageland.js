import React from 'react'
import './homepageland.css'
import landpng from '../../svgimgs/newland.png'

function Homepageland() {
    return (
        <div className="homepageland">
            {/* <div className="homepageland__left"></div>
            <div className="homepageland__right">
                 
            </div>*/}
            <img src={landpng}></img>
        </div>
    )
}

export default Homepageland
