 const ImageCarousel=["https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2018/october/lqRJeN6P7CjlvdVeZyaukhZdQ9NZfzosMNk6C1jn.jpeg ",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2020/august/MecrAVa1MDfcbSZMvRU4vCYyQC2FApFmfhc0wfHl.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2020/july/9M4jEIAPbXZSAUGcrw9i9brUAdAdb1PQK4V0xOYq.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2020/august/uzssgpstR2znKBh7uuT7SE0unho9ARz7bJrMP2xE.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2020/october/kGHyJcoJiZs2fI79ex1alJM0PRQbN2v8Bk62L16m.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2021/january/kqZCdMgDlc1oIqXoTYSGmJcNAH4x7GW7I3UnLW1V.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2021/february/VZ7oNYE6eq9JuMMIqkeDIg6WYzQtqXmM4OWEqMN8.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2021/march/LX0enPHH5vPMuiu6zxzn80kUVb9LbGc3EFmX2xIH.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2021/march/y2B7UGXabJ0mOar7ihkzFPkFGV4navbujoSeg80V.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2021/march/g3es8MZgIi3qJs6E9Y3LrvRzrLJwgyFbWC0zbHOW.jpeg",
"https://media.monsterindia.com/trex/prod-cdn/media/promotedemployer/2021/april/S7ByOesIGjQTu8FVfyGsPsQUfJc5jBXk5uzowf80.jpeg"]


export default ImageCarousel;