 const slider__2itmes = [
    { name:"Finance",
        svg:'<defs><style></style></defs><path class="a" d="M77.786,42.445H42.814L66.1,65.735a2.365,2.365,0,0,0,3.27.1,35.3,35.3,0,0,0,10.778-20.76,2.362,2.362,0,0,0-2.367-2.631Zm-2.333-9.55A35.455,35.455,0,0,0,42.563.006a2.372,2.372,0,0,0-2.476,2.388V35.371H73.066a2.37,2.37,0,0,0,2.386-2.476Zm-42.439,9.55V7.473a2.362,2.362,0,0,0-2.629-2.367A35.345,35.345,0,0,0,.021,41.32c.643,18.885,16.9,34.372,35.8,34.135a35.1,35.1,0,0,0,19.935-6.489,2.342,2.342,0,0,0,.231-3.549Z" transform="translate(0 0)"/></svg>',
        vacancies:1000,

    },
    { name:"Architecture",
        svg:"kasdj",
        vacancies:1100,

    },
    { name:"Marketing",
        svg:"kasdj",
        vacancies:1000,

    },
    { name:"Development",
        svg:"kasdj",
        vacancies:1000,

    },{ name:"Finance",
        svg:"kasdj",
        vacancies:1000,

    }
]

export default slider__2itmes;