//Get jobs action types---->

export const GET_JOB_REQUEST = "GET_JOB_REQUEST"
export const GET_JOB_FAILURE = "GET_JOB_FAILURE"
export const GET_JOB_SUCCESS = "GET_JOB_SUCCESS"
